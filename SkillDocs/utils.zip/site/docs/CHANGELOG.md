# Changelog

版本更新日志

### [0.0.10](https://github.paic.com.cn/PhFE/h5_utils/compare/v0.0.9...v0.0.10) (2020-07-16)

### Features

* 🎸 新增金额格式化、字符串脱敏、获取url参数方法 ([7ed045e](https://github.paic.com.cn/PhFE/h5_utils/commit/7ed045e384b580963d7d9c5974f4ec0effdaf5cc))
* 🎸 新增银行卡格式化、日期格式化方法 ([b3f0b37](https://github.paic.com.cn/PhFE/h5_utils/commit/b3f0b371e6350af20b751528f7209f7d3f5180a9))
* 优化项目打包 ([63af9bb](https://github.paic.com.cn/PhFE/h5_utils/commit/63af9bb5c535ce40c89367547160ac1aca584e7e))
* 新建项目 ([8fd45b8](https://github.paic.com.cn/PhFE/h5_utils/commit/8fd45b8676f47450c48a4b1741b4a7b51b2814ff))

